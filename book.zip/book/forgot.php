<?php
include 'check_session.php'; 
include '../config.php';
$email = $_POST['email'];
$query = "SELECT * FROM users WHERE email='$email'";
$result = $con->query($query);
$rows = mysqli_num_rows($result);
$data = $result->fetch_assoc();
if ($rows>0) {
	
	echo header('location:reset.php?id='.$data['id']);
	
}
else
{
  echo "email not matched!";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="">
    <p>
    	<label>Email :</label>
    	<input type="text" name="email">
    </p>

    <input type="submit" name="submit" value="check">
</form>
</body>
</html>
