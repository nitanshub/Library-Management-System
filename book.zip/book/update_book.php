<?php
 include 'check_session.php';
include 'config.php';
$id = $_POST['id'];
$bookname = $_POST['bookname'];
$bookprice = $_POST['bookprice'];
$filename = $_FILES['file']['name'];
$tempfile = $_FILES['file']['tmp_name'];
$destination = 'uploads/'.$filename;
move_uploaded_file($tempfile,$destination);
$query = "UPDATE books SET book_name='$bookname',book_price='$bookprice',url='$filename'WHERE id='$id'";


if ($con->query($query)) {
	header('location:book.php');
}else{
	echo mysqli_error($con);
}

 ?>