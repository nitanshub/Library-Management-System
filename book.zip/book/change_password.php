<?php

include 'check_session.php';
include("config.php");
if(isset($_POST['submit']))
{
 $oldpass=$_POST['currentPassword'];
 $id=$_SESSION['id'];
 $newpassword=$_POST['newPassword'];
$query="SELECT password FROM users WHERE  id='$id'";

$result=$con->query($query);
$num=mysqli_fetch_array($result);
if($num>0)
{
 $change_password="UPDATE users SET password='$newpassword' WHERE id='$id'";
 if($con->query($change_password))
echo "Password Changed Successfully !!";
}
else
{

  echo "password not changed!";
}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body><section>
		<?php include 'menu.php'; ?>
        <div>
        <h3 align="center">CHANGE PASSWORD</h3>

<form method="post" action="" align="center">
Current Password:<br>
<input type="password" name="currentPassword">
<br>
New Password:<br>
<input type="password" name="newPassword">
<br>
Confirm Password:<br>
<input type="password" name="confirmPassword">
<br><br>
<input type="submit" name="submit">
</form>
<br>
<br>
	</div>
     
</body>
</html>
</body>
</html>