<?php 
include 'check_session.php';
include 'config.php';
$id = $_GET['id'];
$query = "DELETE FROM books WHERE id='$id'";
if ($con->query($query)) {
	header('location:book.php');
}else
{
	echo mysqli_error($con);
}

 ?>