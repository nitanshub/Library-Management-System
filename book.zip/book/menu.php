<style>
  body{background-color: ivory;}
  a{color: black;}
</style>
<div align="center">
 
<nav>  
   
    	Welcome <?php echo $_SESSION['fullname'] ?> (<?php echo $_SESSION['type'] ?>)

    	<?php
    
    	if($_SESSION['type']=='Admin'){ 
    	?>
      <hr>
      <a href="admin.php">Admin</a>
      <br><hr>
      <a href=author.php>Author</a>
      <br><hr>
  <?php } ?>

  
  <?php
    
    	if($_SESSION['type']!='Reader'){ 
    	?>
  
      <a href=reader.php>Reader</a>

  <?php } ?>
  <br><hr>
      <a href="book.php">Book List</a>
   <br><hr>   
      <a href="profile.php?id=<?php echo $_SESSION['id'] ?>">Profile</a>
     
  <br><hr>
      <a href="change_password.php">Change Password</a>
  <br><hr> 
      <a href="logout.php">Logout</a>
  <br><hr>    
      <a href="downloadlink.php">Download link</a>
      
    <hr>
</nav>
</div>