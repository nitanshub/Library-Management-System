<?php 
include 'check_session.php';
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
			body{background-color: ivory;}
	</style>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<section>
		<?php include 'menu.php'; ?>
        <h1 align="center">Welcome Admin</h1>
  	</section>
  
<div align="center">
        <p>
        	HELLO WELCOME TO THE BOOK LIBRARY.
        	<br><br>
        	<?php echo $_SESSION['fullname'] ?> (<?php echo $_SESSION['type'] ?>)
        </p>
        </div>


</body>
</html>