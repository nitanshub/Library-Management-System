 <?php 
$link = $_POST['link'];
echo "$link";
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" accept="uniquelink.php">
		download link :
        <input type="url" name="link"><br><br>
        <input type="submit" name="submit">
	</form>
	


</body>
</html>