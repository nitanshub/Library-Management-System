<?php 
if (isset($_POST['submit'])) {
	include 'config.php';
	$fullname = $_POST['fname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$type = $_POST['type'];
	$imagename = $_FILES['image']['name'];
    $tempimagename = $_FILES['image']['tmp_name'];
	move_uploaded_file($tempimagename,'../images/'.$imagename);

	$query = "INSERT INTO users VALUES(NULL,'$fullname','$email','$password','$type','$imagename')";
	if ($con->query($query)) {
		
		header('location:login.php');
	}
	else
	{
		echo mysqli_error($con);
	}
}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Register Here...</title>
	<style>
		body{background-color: orange;}
		a{
			color: black;
		}
	</style>
</head>
<body>
	<div align="center">
    <h1>NEW REGISTERATION</h1>
    <form method="post" action="" enctype="multipart/form-data">
    	<p>
    		<a href="index.php">HOME</a>
    	</p>
    	<p>
    		<label>Full Name</label>
    		<input type="text" name="fname">
    	</p>
    	<p>
    		<label>Email</label>
    		<input type="email" name="email">
    	</p>
    	<p>
    		<label>Password</label>
    		<input type="text" name="password">
    	</p>
    	<p>
    		<label>Type</label>
    		<select name="type">
    			<option value="Admin">Admin</option>
    			<option value="Author">Author</option>
    			<option value="Reader">Reader</option>
    		</select>
    	</p>
    	<p>
    		<label>	Image	</label>
    		<input type="file" name="image">
    	</p>
    	<br>
    	<input type="submit" name="submit">
    	<br><br>
        
    </div>	
    </form>
</body>
</html>

