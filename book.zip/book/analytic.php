<?php 
include 'check_session.php';
include 'config.php';
$id = $_GET['id'];
$query = "SELECT * FROM books WHERE id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();
//download count
$query_download = "SELECT * FROM book_download_count WHERE book_id='$id'";
$result_download = $con->query($query_download);
$data_download = $result_download->fetch_assoc();

//read count
$query_read = "SELECT * FROM book_read_count WHERE book_id='$id'";
$result_read = $con->query($query_read	);
$data_read = $result_read->fetch_assoc();

$query_downdlist = "SELECT users.id,users.fullname,book_download_log.user_id,count(*) as count
FROM book_download_log INNER JOIN users ON 
book_download_log.user_id=users.id WHERE book_download_log.book_id='$id'
group by book_download_log.user_id";

$result_downdlist =$con->query($query_downdlist);
//$data_downdlist=$result_downdlist->fetch_assoc();

$query_readlist = "SELECT users.id,users.fullname,book_read_log.user_id,count(*) as count
FROM book_read_log INNER JOIN users ON 
book_read_log.user_id=users.id WHERE book_read_log.book_id='$id'
group by book_read_log.user_id";

$result_readlist =$con->query($query_readlist);


 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<section>
		<?php include 'menu.php'; ?>
		<h3 align="center">Analytics of Book :- <?php echo $data['book_name'];?></h3>
		<table align="center" border="1px solid black">
			<tr>
				<th>Download count</th>
				<th>Read count</th>
			</tr>
			<tr>
				<td><?php echo $data_download['download_count'];?></td>
				<td><?php echo $data_read['read_count'];?></td>
			</tr>
		</table><br>
		<table align="center" border="1px solid black">
			<tr>
				<th>Download By</th>
				<th>Download count</th>
			</tr>
			<?php 
		while ($data_downdlist=$result_downdlist->fetch_assoc()) {
			?>
			<tr>
				<td><?php echo $data_downdlist['fullname'];?></td>
				<td><?php echo $data_downdlist['count'];?></td>
			</tr>
			<?php
		}
			 ?>
			
			
		</table><br>
		<table align="center" border="1px solid black">
			<tr>
				<th>Read By</th>
				<th>Read count</th>
			</tr>
			<?php 
		while ($data_readlist=$result_readlist->fetch_assoc()) {
			?>
			<tr>
				<td><?php echo $data_readlist['fullname'];?></td>
				<td><?php echo $data_readlist['count'];?></td>
			</tr>
			<?php
		}
			 ?>
		</table>
        
	
	</section>	
</body>
</html>