<?php 
include '../config.php';
$id = $_POST['id'];
$new_password = $_POST['password'];
$confirm_password = $_POST['confirmpassword'];
$query = "UPDATE users SET password='$new_password' WHERE id='$id'";
if ($new_password==$confirm_password) {
	
	if ($con->query($query)) 
	{
		
		echo header('location:login.php');
	}
	else
	{

		echo mysqli_error($con);
	}
}
else
{
    echo "New password and Confirm password not matched!";
}

 ?>