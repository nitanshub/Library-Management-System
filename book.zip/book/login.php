<?php 
//include 'check_session.php';
session_start();
include 'config.php';
if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "SELECT * FROM users WHERE fullname='$username' AND password='$password'";
	$result = $con->query($query);
	$rows = mysqli_num_rows($result);
	$data = $result->fetch_assoc();

	if ($rows==1) {
		$_SESSION = $data;
		if ($data['type']=='Reader') {
			
			header('location:book.php');
		}
		else{
			if ($data['type']=='Author') {
				
				header('location:book.php');
			}
			else{
				header('location:admin.php');
			}
		}

	}else{
		echo mysqli_error($con);
	}
}


 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style>
 		body{background-color: blueviolet;
           color: white;
 		}
 		a{
 			color: white;
 		}

 	</style>
 </head>
 <body>
    <h1 align="center">LOGIN</h1>
    <form method="post" action="">
    	<div align="center">
    	<p>
    		<a href="index.php">HOME</a>
    	</p>
    	<table align="center">
    		<tr>
    			<td>FULL NAME :</td>
    			<td><input type="text" name="username"></td>
    		</tr>
    		<tr>
    			<td>PASSWORD :</td>
    			<td><input type="text" name="password"></td>
    		</tr>

    		<tr>
    			<td colspan="2" align="center"><input type="submit" name="submit" value="Login"></td>
    		</tr>

    		<tr>
    			<td><a href="register.php">NEW REGISTERS</a></td>
    		</tr>
    		<tr>
    			<td><a href="forgot.php">FORGOT PASSWORD</a></td>
    		</tr>
    		
    	</table>
    	
    </form>
 </body>
 </html>