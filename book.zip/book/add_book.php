<?php 
include 'check_session.php';
include 'config.php';

if (isset($_POST['save'])) {
	$bookname = $_POST['bookname'];
    $bookprice = $_POST['bookprice'];
    $filename = $_FILES['file']['name'];
    $tempfile = $_FILES['file']['tmp_name'];
    $destination = 'uploads/'.$filename;
    $extension = pathinfo($filename,PATHINFO_EXTENSION);
    if ($extension=='pdf') {
    	if (move_uploaded_file($tempfile, $destination)) {
    		$query = "INSERT INTO books VALUES(NULL,'$bookname','$bookprice','$filename')";
            
    		if ($con->query($query)) {
    			header('location:book.php');
    		}
    		else{
    			echo "failed to upload file";
    		}
    	}
    }
    else
    {
       echo "Your file extension must be .pdf";
    }
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <form method="post" action="add_book.php" enctype="multipart/form-data">
    	<p>
    		<label>Book Name :</label>
    		<input type="text" name="bookname">
    	</p>
    	<p>
    		<label>Book price :</label>
    		<input type="text" name="bookprice">
    	</p>
    	<p>
    		<label>Upload book in PDF :</label>
    		<input type="file" name="file">
    	</p>
    	<input type="submit" value="Upload" name="save">

    </form>
</body>
</html>