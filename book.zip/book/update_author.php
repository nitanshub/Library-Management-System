<?php
 include 'check_session.php';
include 'config.php';
$id = $_POST['id'];
$fullname = $_POST['fname'];

$email = $_POST['email'];

$imagename = $_FILES['image']['name'];
$tempimagename = $_FILES['image']['tmp_name'];
move_uploaded_file($tempimagename,'images/'.$imagename);
$query = "UPDATE users SET fname='$fullname',email='$email',image='$imagename' WHERE id='$id'";

if ($con->query($query)) {
		header('location:profile.php?id='.$_SESSION['id']);
}else{
	echo mysqli_error($con);
}

 ?>