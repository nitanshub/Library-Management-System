<?php 
$id = $_GET['id'];
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
    <form method="post" action="update_password.php">
    	<input type="hidden" name="id" value="<?php echo $id;?>">
     	<p>New Password :<input type="password" name="password"></p>
    
     	<p>confirm Password :<input type="password" name="confirmpassword"></p>
     	<input type="submit" name="submit">
    </form>
 </body>
 </html>