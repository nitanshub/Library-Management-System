<?php
include 'check_session.php'; 
include 'config.php';
$id = $_GET['id'];
$query = "SELECT * FROM books WHERE id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
     <form method="post" action="update_book.php" enctype="multipart/form-data">
     	<input type="hidden" name="id" value="<?php echo $data['id'];?>">
     	<p>
            <label>Book Name :</label>
            <input type="text" name="bookname" value="<?php echo $data['book_name'];?>">
        </p>
        <p>
            <label>Book price :</label>
            <input type="text" name="bookprice" value="<?php echo $data['book_price'];?>">
        </p>
        <p>
            <label>Upload book :</label>
            <input type="file" name="file">
        </p>
        <input type="submit" value="Update" name="save">
    	
     	
     </form>
</body>
</html>