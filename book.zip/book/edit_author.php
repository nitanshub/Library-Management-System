<?php 
include 'check_session.php';
include 'config.php';
$id = $_SESSION['id'];
$query = "SELECT * FROM users WHERE id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
    <section>
        <?php include 'menu.php'; ?>
        <div>
        <h1 align="center">Profile</h1>
    </div>
     <form align="center" method="post" action="update_author.php"  enctype="multipart/form-data">
     	<input type="hidden" name="id" value="<?php echo $data['id'];?>">
     	<p>
    		<label> Name</label>
    		<input type="text" name="fname" value="<?php echo $data['fullname'];?>">
    	</p>
    	<p>
    		<label>Email</label>
    		<input type="email" name="email" value="<?php echo $data['email'];?>">
    	</p>
    	<p>
    		<label>Image</label>
    		<input type="file" name="image">
    	</p>
    	<input type="submit" name="submit">
    	
     	
     </form>
 </section>
</body>
</html>