<?php 
include 'check_session.php';
include 'config.php';
$query = "SELECT * FROM books";
$result=$con->query($query);
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<section>
		<?php include 'menu.php'; ?>
        <div>
        <h1 align="center">Book List</h1>
        <?php
        if($_SESSION['type']=='Author'){
        ?>
    </div>
    <div align="center">
        <a href="add_book.php">Add Book</a>
    </div>
    <?php } ?>
	    </div>
	    <form method="post" action="" enctype="multipart/form-data">
		<table align="center" border="1px solid black" width="50%">
			<tr>
				<th>Sr No.</th>
				<th>Book Name</th>
				<th>Book Price</th>
				<th>File Upload</th>
				<th>Action</th>
				<?php
    	//adding condition not to show analytic to reader
    	if($_SESSION['type']!='Reader'){ 
    	?>
				<th>Analytics</th>
			<?php } ?>

			</tr>
			<?php
			$count = 1;
			while ($data=$result->fetch_assoc()) {
				
			  	echo "<tr>";
				echo "<td>".$count++."</td>";
				echo "<td>".$data['book_name']."</td>";
				echo "<td>".$data['book_price']."</td>";
				echo "<td><a href='view_book.php?id=".$data['id']."'>View File</a></td>";
				 //adding condition not to show edit and delete to reader
				if($_SESSION['type']!='Reader'){  
				echo "<td><a href='edit_book.php?id=".$data['id']."'>Edit</a>/
				      <a href='delete_book.php?id=".$data['id']."'>Delete</a>/
				      <a href='download_book.php?id=".$data['id']."' download='http://localhost/author/uploads/'".$data['url']."'>Download</a></td>";
				  }else{

				     echo "<td>
				      <a href='download_book.php?id=".$data['id']."' download='http://localhost/author/uploads/'".$data['url']."'>Download</a></td>";
				  }
				   //adding condition not to show analytic to reader
				if($_SESSION['type']!='Reader'){       
				echo "<td><a href='analytic.php?id=".$data['id']."'>analytics</a></td>";
			}
			    echo "</tr>";
			  }  
			
			?>
		</table>
	</form>
	</section>	
</body>
</html>