<?php 
include 'check_session.php';
include 'config.php';
$id = $_GET['id'];
$query = "SELECT * FROM books WHERE id='$id'";
$result = $con->query($query);
$data1 = $result->fetch_assoc();




$query = "INSERT INTO book_read_log VALUES(NULL,".$id.",".$_SESSION["id"].")";
$con->query($query);

$query = "SELECT * FROM book_read_count WHERE book_id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();

if($data){
	$count = $data['read_count']+1;
	$query = "UPDATE book_read_count SET read_count=".$count." WHERE id=".$data['id'];
	$con->query($query);

}else{
	$query = "INSERT INTO book_read_count VALUES(NULL,".$id.",1)";
	$con->query($query);


}

 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Download</title>
 </head>
 <body>
 	<!-- <form method="post" accept="uniquelink.php">
		download link :
        <input type="url" name="link"><br><br>
        <input type="submit" name="submit">
	</form> -->
 	<iframe style="width:100%;height:500px" src="http://localhost/book/uploads/<?= $data1['url'] ?>"></iframe>
</body>
 </html>
s