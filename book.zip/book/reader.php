<?php 
include 'check_session.php';
include 'config.php';
$query = "SELECT id,fullname,email,image FROM users WHERE type='Reader'";
$result = $con->query($query);
// $data=$result->fetch_assoc();
//print_r($query);exit;
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<section>
		<?php include 'menu.php'; ?>
        <div>
            <h1 align="center">Reader List</h1>
	    </div>
	    <form method="post" action="" enctype="multipart/form-data">
		<table align="center" border="1px solid black" width="50%">
			<tr>
				<th>Reader Name</th>
				<th>Email</th>
				<th>Image</th>
				<!-- <th>Action</th> -->
			</tr>
			<?php
			while ($data=$result->fetch_assoc()) {
			  	echo "<tr>";
				echo "<td>".$data['fullname']."</td>";
				echo "<td>".$data['email']."</td>";
				echo "<td><img src='images/".$data['image']."'></td>";
				//echo "<td><a href='edit_author.php?id=".$data['id']."'>Edit</a>/<a href='delete_author.php?id=".$data['id']."'>Delete</a></td>";
			echo "</tr>";
			  }  
			
			?>
		</table>
	</form>
	
	</section>	
</body>
</html>