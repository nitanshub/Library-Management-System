<?php 
include 'check_session.php';
include 'config.php';
$id = $_GET['id'];
$query = "SELECT * FROM books WHERE id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();

//insert query
$query = "INSERT INTO book_download_log VALUES(NULL,".$id.",".$_SESSION["id"].")";
$con->query($query);

$query = "SELECT * FROM book_download_count WHERE book_id='$id'";
$result = $con->query($query);
$data = $result->fetch_assoc();

if($data){
	$count = $data['download_count']+1;
	$query = "UPDATE book_download_count SET download_count=".$count." WHERE id=".$data['id'];
	$con->query($query);

}else{
	$query = "INSERT INTO book_download_count VALUES(NULL,".$id.",1)";
	$con->query($query);
}

 ?>
 