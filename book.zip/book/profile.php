<?php 
include 'check_session.php';
include 'config.php'; 
$query = "SELECT * FROM users";
$result = $con->query($query);
$data = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		p{color: red;}
	</style>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<section>
		<?php include 'menu.php'; ?>
		<div align="center">
			<p>Name :- <?php echo $_SESSION['fullname'] ?> (<?php echo $_SESSION['type'] ?>)</p>
            
            <p>Email :- <?php echo $_SESSION['email'] ?> (<?php echo $_SESSION['type'] ?>) </p>
            <p>Image :- <img src='images/<?php echo $_SESSION['image'] ?>' width="100px"></p>
            <p align="center"><a href="edit_author.php?id=<?php echo $data['id'] ?>">Update</a></p>
		</div>
	</section>
     
</body>
</html>
