<?php 
ob_start();
$con = new mysqli("localhost","root","","library");
 ?>