<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div align="center">
		<form method="post" action="author.php" enctype="multipart/form-data">
	    	<p>
	    		<label> Name </label>
	    		<input type="text" name="name">
	    	</p>
		    
	    	<p>
	    		<label>Email</label>
	    		<input type="email" name="email">
	    	</p>
	    	<p>
	    		<label>Image</label>
	    		<input type="file" name="image">
	    	</p>
	    	<input type="submit" name="submit">

    </form>
	</div>
    
</body>
</html>