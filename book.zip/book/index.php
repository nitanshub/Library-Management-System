<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style>
		body{background-color:deepskyblue;}
		a{
			color: black;
		}
	</style>	
</head>
<body>
	<div align="center">
		<u>
			<h1>WELCOME TO E-BOOK LIBRARYS </h1>	
		</u>
	
<p>
<a href="login.php">LOGIN</a>
</p>
<p>
<a href="register.php">REGISTRATION</a>
</p>
</div>
</body>
</html>